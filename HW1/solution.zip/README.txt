For Milestone 1, Siyang Sun wrote the following 2 functions:
    uint256_create_from_u32
    uint256_create
and Tianji Li wrote the following 2 functions: 
    uint256_get_bits
    uint256_is_bit_set