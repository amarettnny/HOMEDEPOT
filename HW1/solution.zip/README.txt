For Milestone 1, Siyang Sun wrote the following 2 functions:
    uint256_create_from_u32
    uint256_create
and Tianji Li wrote the following 2 functions: 
    uint256_get_bits
    uint256_is_bit_set

For Milestone 2, Tianji Li wrote the following functions with their unit tests:
    uint256_create_from_hex
    uint256_format_as_hex
    uint256_add
    uint256_sub
and Siyang Sun wrote the following functions with their unit tests:
    uint256_negate
    uint256_mul
    uint256_lshift