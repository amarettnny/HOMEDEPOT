Group members:
    Siyang Sun
    Tianji Li

Contributions:
MS1:
    Siyang wrote the Makefile, Tianji started the main.cpp

MS2:
    Siyang wrote the main.cpp and storing in cache
    Tianji wrote the cache_sim.cpp

TODO (for MS3): best cache report
