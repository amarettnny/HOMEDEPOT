Group members:
    Siyang Sun
    Tianji Li

Contributions:
MS1:
    Siyang wrote the Makefile, Tianji started the main.cpp

TODO (for MS3): best cache report
