Team members:
Siyang Sun
Tianji Li

Contributions:
For Milestone 1:
    Tianji wrote both the grayscale and kaleidoscope functions and all related helper functions, 
    including their unit test.

    Siyang wrote both the rgb and fade functions and all related helper functions, including 
    their unit tests. 

For Milestone 2:
    Tianji wrote the graycale function and all related helper functions in Assembly.
    
    Siyang wrote the rgb function and the compute_index helper function in Assembly.

For Milestone 3:
    Tianji wrote the kaleidoscope function in Assembly.
    
    Siyang wrote the fade function and the helper function gradient in Assembly.