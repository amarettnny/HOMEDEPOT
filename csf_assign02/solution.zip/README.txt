Team members:
Siyang Sun
Tianji Li

Contributions:
For Milestone 1:
    Tianji wrote both the grayscale and kaleidoscope functions and all related helper functions, 
    including their unit test.

    Siyang wrote both the rgb and fade functions and all related helper functions, including 
    their unit tests. 
